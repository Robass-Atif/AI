


city_map={
    'Warehouse':{'A':5,'B':10},
    'A':{'Warehouse':5,'C':15},
    'B':{'Warehouse':10,'C':20},
    'C':{'A':15,'B':20}
}
delivery_point=['A','B']

# def delivery_point(city_map,delivery_point):
#     visited=[]
#     path=[]
#     priorty_queue=city_map

   
print(city_map.keys())








# delivery_point(city_map,delivery_point)