

def cube(num):
    return num ** 3

print(cube(3))  

